package com.android.mysubmissiongithubuser.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.mysubmissiongithubuser.R
import com.android.mysubmissiongithubuser.databinding.ActivityMainBinding
import com.android.mysubmissiongithubuser.response.GithubResponse
import com.android.mysubmissiongithubuser.response.ItemsItem
import com.android.mysubmissiongithubuser.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var userAdapter : UserAdapter

    //view model
    private val viewModel: ViewModel by viewModels()

    companion object{
        private const val TAG = "MainActivity"
        private const val QUERY = "Arif"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)
        mainViewModel.userData.observe(this) { userData ->
            setUserData(userData)
        }

        mainViewModel.userData.observe(this) { userData ->
            setUserData(userData)
        }
        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        val layoutManager = LinearLayoutManager(this)
        binding.rvUsers.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvUsers.addItemDecoration(itemDecoration)

        userAdapter = UserAdapter(
            onClick = { user ->
                val moveIntent = Intent(this@MainActivity, DetailUserActivity::class.java)
                moveIntent.putExtra(DetailUserActivity.EXTRA_USER, user.login)
                startActivity(moveIntent)
            }
        )
        binding.rvUsers.adapter = userAdapter



        with(binding){
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                        val query = searchView.text.toString()
                        searcUser(query)
                        searchView.hide()
                        true // Konsumsi event
                    } else {
                        false
                    }
                }
        }
    }

    private fun searcUser(query: String) {
        showLoading(true)
        val client = ApiConfig.getApiService().getListUsers(query)
        client.enqueue(object : Callback<GithubResponse> {
            override fun onResponse(call: Call<GithubResponse>, response: Response<GithubResponse>) {
                showLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        setUserData(responseBody.items)
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                    Toast.makeText(this@MainActivity, "Gagal melakukan pencarian.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
                Toast.makeText(this@MainActivity, "Terjadi kesalahan jaringan.", Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun setUserData(users : List<ItemsItem?>?) {
        if (users != null) {
            userAdapter.submitList(users.filterNotNull())
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}