package com.android.mysubmissiongithubuser.retrofit

import com.android.mysubmissiongithubuser.response.DetailUserResponse
import com.android.mysubmissiongithubuser.response.GithubResponse
import com.android.mysubmissiongithubuser.response.FollowersResponse
import com.android.mysubmissiongithubuser.response.FollowersResponseItem
import com.android.mysubmissiongithubuser.response.OrgResponseItem
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    //@Headers("Authorization: token <Your Personal Access Token>")
    @GET("search/users")
    fun getListUsers(
        @Query("q")  query: String
    ): Call<GithubResponse>

    @GET("users/{userId}")
    fun getDetailUser(
        @Path("userId") userId: String
    ): Call<DetailUserResponse>

    @GET("orgs/dicodingacademy/members")
    fun getOrgMembers(): Call<List<OrgResponseItem>>

    @GET("users/{userId}/{target}")
    fun getFollowers(
        @Path("userId") userId: String,
        @Path("target") target: String
    ): Call<List<FollowersResponseItem>>

}