package com.android.mysubmissiongithubuser.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModel
import com.android.mysubmissiongithubuser.R
import com.android.mysubmissiongithubuser.databinding.ActivityDetailUserBinding
import com.android.mysubmissiongithubuser.response.DetailUserResponse
import com.android.mysubmissiongithubuser.retrofit.ApiConfig
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding

    private val viewModel: ViewModel by viewModels()
    companion object {
        const val EXTRA_USER = "extra_user"
        private const val TAG = "DetailUserActivity"
        //view pager2
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_follower,
            R.string.tab_following
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fetchGitHubUserDetail(intent.getStringExtra(EXTRA_USER).toString())
        //view pager2
        val sectionsPagerAdapter = SectionsPagerAdapter(this)

        sectionsPagerAdapter.username = intent.getStringExtra(EXTRA_USER).toString()
        val viewPager = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        val tabs = binding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f
    }
    private fun fetchGitHubUserDetail(userLogin: String) {
        showLoading(true)
        val apiService = ApiConfig.getApiService()
        val call = apiService.getDetailUser(userLogin)

        call.enqueue(object : Callback<DetailUserResponse> {
            @SuppressLint("SetTextI18n")
            override fun onResponse(
                call: Call<DetailUserResponse>,
                response: Response<DetailUserResponse>

            ) {
                showLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        binding.tvUserName.text = responseBody.login
                        binding.tvUserName2.text = responseBody.name
                        binding.follower.text = "${responseBody.followers} Followers"
                        binding.following.text = "${responseBody.following} Following"
                        Log.d(TAG, "Following: ${responseBody.following}, Followers: ${responseBody.followers}")
                        Glide.with(this@DetailUserActivity)
                            .load(responseBody.avatarUrl)
                            .apply(RequestOptions.circleCropTransform())
                            .into(binding.ivUsers)

                    }
                    CoroutineScope(Dispatchers.Main).launch {
                        delay(700)
                        showLoading(false)
                    }

                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                showLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    private fun updateView(){

    }


    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}