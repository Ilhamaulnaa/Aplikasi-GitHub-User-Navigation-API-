package com.android.mysubmissiongithubuser.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.android.mysubmissiongithubuser.response.FollowersResponseItem
import com.android.mysubmissiongithubuser.databinding.ItemListBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions


class FollowAdapter(private val onClick: (FollowersResponseItem) -> Unit
) : ListAdapter<FollowersResponseItem, FollowAdapter.MyViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowAdapter.MyViewHolder {
        val binding = ItemListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }
    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val user = getItem(position)
        holder.bind(user)

        holder.itemView.setOnClickListener {
            onClick(user)
        }

    }

    class MyViewHolder(val binding: ItemListBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(user: FollowersResponseItem) {
            binding.tvUserName.text = user.login
            Glide.with(itemView)
                .load(user.avatarUrl)
                .apply(RequestOptions.circleCropTransform())
                .into(binding.ivUsers)
        }
    }

    companion object {

        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<FollowersResponseItem>(){
            override fun areItemsTheSame(oldItem: FollowersResponseItem, newItem: FollowersResponseItem): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(oldItem: FollowersResponseItem, newItem: FollowersResponseItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}